<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Functions with Return Values</title>
</head>
<body>
    <?php
    function printMe($param = null){
        echo $param;
    }
    printMe("This is Test");
    printMe();
    printMe("<br />This is Test");
    printMe();printMe();
    ?>
</body>
</html>