<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writting PHP Function</title>
</head>
<body>
    <h2>first time for PHP</h2>
    <?php
    function WriteMessage(): void{
        echo"You are really a nice person, Have a nice time!";
    }
    WriteMessage();
    ?>
</body>
</html>