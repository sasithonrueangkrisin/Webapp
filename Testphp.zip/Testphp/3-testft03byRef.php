<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Parameters by Reference</title>
</head>
<body>
    <?php
    function addFive($num){
        $num += 5;
    }
    function addSix($num){
        $num += 6;
    }

    $origrum = 10;
    addFive( $origrum);

    echo "Original Value is $origrum <br />";

    addSix($origrum);
    echo "Original Value is $origrum <br/>";
    ?>
</body>
</html>