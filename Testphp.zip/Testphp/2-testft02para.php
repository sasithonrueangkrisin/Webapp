<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function</title>
</head>
<body>
    <h2>PHP Function with Parameters</h2>
    <?php
    function addFunction($sum1, $sum2): void{
        $Sum = $sum1 + $sum2;
        echo "Sum of the two numbers is: $Sum";
    }
    addFunction(10, 20);
    ?>
</body>
</html>